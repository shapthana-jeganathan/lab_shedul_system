<?php
session_start();
require_once 'db_connect.php';
require_once 'functions.php';

check_login();
require_role(['coordinator', 'instructor']);

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$today = date('Y-m-d');

// Detect if instructor is in edit mode via URL parameter ?edit=1
$edit_mode = false;
if ($role === 'instructor' && isset($_GET['edit']) && $_GET['edit'] === '1') {
    $edit_mode = true;
}

// Fetch all student IDs from enrollments
$students = [];
$res = $conn->query("SELECT DISTINCT student_id FROM student_enrollments ORDER BY student_id");
while ($row = $res->fetch_assoc()) {
    $students[] = $row['student_id'];
}

$selected_student = $_GET['student_id'] ?? null;
$records = [];

if ($selected_student) {

    // Handle attendance update only if user is instructor, in edit mode, and form submitted
    if ($role === 'instructor' && $edit_mode && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['attendance'])) {
        foreach ($_POST['attendance'] as $schedule_id => $present_val) {
            $is_present = ($present_val === 'present') ? 1 : 0;

            // Check if attendance record exists
            $check_stmt = $conn->prepare("SELECT COUNT(*) FROM attendance WHERE student_id = ? AND schedule_id = ?");
            $check_stmt->bind_param("si", $selected_student, $schedule_id);
            $check_stmt->execute();
            $check_stmt->bind_result($count);
            $check_stmt->fetch();
            $check_stmt->close();

            if ($count > 0) {
                $update_stmt = $conn->prepare("UPDATE attendance SET is_present = ? WHERE student_id = ? AND schedule_id = ?");
                $update_stmt->bind_param("isi", $is_present, $selected_student, $schedule_id);
                $update_stmt->execute();
                $update_stmt->close();
            } else {
                $insert_stmt = $conn->prepare("INSERT INTO attendance (student_id, schedule_id, is_present) VALUES (?, ?, ?)");
                $insert_stmt->bind_param("sii", $selected_student, $schedule_id, $is_present);
                $insert_stmt->execute();
                $insert_stmt->close();
            }
        }
        echo "<p style='color:green; text-align:center;'>Attendance updated successfully.</p>";
    }

    // Fetch attendance records for the student
    $stmt = $conn->prepare("
        SELECT s.lab_id, s.schedule_date, s.schedule_time, s.schedule_id, a.is_present
        FROM lab_schedule s
        JOIN student_enrollments e ON s.schedule_id = e.schedule_id
        LEFT JOIN attendance a ON a.schedule_id = s.schedule_id AND a.student_id = e.student_id
        WHERE e.student_id = ?
        ORDER BY s.schedule_date DESC, s.schedule_time DESC
    ");
    $stmt->bind_param("s", $selected_student);
    $stmt->execute();
    $records = $stmt->get_result();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Attendance by Student</title>
    <style>
        body { font-family: Arial; background: #f4f4f4; padding: 20px; }
        select, button { padding: 6px; font-size: 16px; }
        table { width: 90%; border-collapse: collapse; margin-top: 20px; background: white; }
        th, td { padding: 10px; border: 1px solid #ccc; text-align: center; }
        th { background: #1a73e8; color: white; }
        h2, h3 { text-align: center; }
        .status-present { color: green; font-weight: bold; }
        .status-absent { color: red; font-weight: bold; }
        .status-not-yet { color: gray; font-style: italic; }
        label { cursor: pointer; margin-right: 15px; }
        input[type="radio"] { margin-right: 5px; }
        .edit-toggle {
            text-align: center; margin: 15px 0;
        }
        .edit-toggle a {
            text-decoration: none; color: #1a73e8; font-weight: bold;
        }
    </style>
</head>
<body>

<h2>View Attendance by Student</h2>

<form method="get" style="text-align: center;">
    <label>Select Student ID:</label>
    <select name="student_id" required>
        <option value="">-- Choose Student ID --</option>
        <?php foreach ($students as $sid): ?>
            <option value="<?= htmlspecialchars($sid) ?>" <?= ($sid == $selected_student) ? 'selected' : '' ?>>
                <?= htmlspecialchars($sid) ?>
            </option>
        <?php endforeach; ?>
    </select>
    <button type="submit">View</button>
</form>

<?php if ($role === 'instructor' && $selected_student): ?>
    <div class="edit-toggle">
        <?php if ($edit_mode): ?>
            <a href="?student_id=<?= urlencode($selected_student) ?>">Switch to View Mode</a>
        <?php else: ?>
            <a href="?student_id=<?= urlencode($selected_student) ?>&edit=1">Switch to Edit Mode</a>
        <?php endif; ?>
    </div>
<?php endif; ?>

<?php if ($selected_student): ?>
    <h3>Attendance for Student: <?= htmlspecialchars($selected_student) ?></h3>

    <?php if ($records && $records->num_rows > 0): ?>
        <?php if ($role === 'instructor' && $edit_mode): ?>
            <form method="post">
        <?php endif; ?>

        <table>
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Lab ID</th>
                    <th>Schedule ID</th>
                    <th>Schedule Date</th>
                    <th>Schedule Time</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $records->fetch_assoc()):
                    $is_present = $row['is_present'];
                    if ($is_present === null) {
                        $status_text = ($row['schedule_date'] > $today) ? "Not yet happened" : "Absent";
                    } else {
                        $status_text = $is_present ? "Present" : "Absent";
                    }
                ?>
                    <tr>
                        <td><?= htmlspecialchars($selected_student) ?></td>
                        <td><?= htmlspecialchars($row['lab_id']) ?></td>
                        <td><?= htmlspecialchars($row['schedule_id']) ?></td>
                        <td><?= htmlspecialchars($row['schedule_date']) ?></td>
                        <td><?= htmlspecialchars($row['schedule_time']) ?></td>
                        <td>
                            <?php if ($role === 'instructor' && $edit_mode && $status_text !== "Not yet happened"): ?>
                                <label style="color:green;">
                                    <input type="radio" name="attendance[<?= $row['schedule_id'] ?>]" value="present" <?= ($is_present == 1) ? 'checked' : '' ?>>
                                    Present
                                </label>
                                <label style="color:red;">
                                    <input type="radio" name="attendance[<?= $row['schedule_id'] ?>]" value="absent" <?= ($is_present === 0 || $is_present === null) ? 'checked' : '' ?>>
                                    Absent
                                </label>
                            <?php else: ?>
                                <?php if ($status_text === "Not yet happened"): ?>
                                    <span class="status-not-yet"><?= htmlspecialchars($status_text) ?></span>
                                <?php elseif ($is_present): ?>
                                    <span class="status-present">Present</span>
                                <?php else: ?>
                                    <span class="status-absent">Absent</span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <?php if ($role === 'instructor' && $edit_mode): ?>
            <div style="text-align: center; margin-top: 15px;">
                <button type="submit">Save Attendance</button>
            </div>
            </form>
        <?php endif; ?>

    <?php else: ?>
        <p style="text-align: center;">No attendance found for this student.</p>
    <?php endif; ?>
<?php endif; ?>

</body>
</html>


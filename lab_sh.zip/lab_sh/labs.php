<?php
include 'db_connect.php';
include 'functions.php';
check_login();
require_role(['coordinator', 'instructor']);

// Fetch labs with schedules, instructors, and group students
$sql = "
SELECT 
    L.lab_id,
    L.lab_name,
    L.location AS lab_location,
    L.equipment_available,
    S.schedule_id,
    S.scheduled_date,
    S.start_time,
    S.end_time,
    U.name AS instructor_name
FROM LABS L
LEFT JOIN LAB_SCHEDULE S ON L.lab_id = S.lab_id AND S.status = 'active'
LEFT JOIN USERS U ON S.instructor_id = U.user_id
WHERE L.is_active = 1
ORDER BY L.lab_name, S.scheduled_date, S.start_time
";

$result = $conn->query($sql);

if (!$result || $result->num_rows === 0) {
    echo "<p>No active labs found.</p>";
    exit();
}

echo "<h2>All Active Labs Overview</h2>";

$last_lab_id = 0;
$labs = [];

while ($row = $result->fetch_assoc()) {
    $labs[$row['lab_id']]['lab_name'] = $row['lab_name'];
    $labs[$row['lab_id']]['location'] = $row['lab_location'];
    $labs[$row['lab_id']]['equipment'] = $row['equipment_available'];
    if ($row['schedule_id']) {
        $labs[$row['lab_id']]['schedules'][] = [
            'schedule_id' => $row['schedule_id'],
            'date' => $row['scheduled_date'],
            'start_time' => $row['start_time'],
            'end_time' => $row['end_time'],
            'instructor_name' => $row['instructor_name']
        ];
    }
}

// Now fetch group lists (students) per schedule
$schedule_ids = [];
foreach ($labs as $lab) {
    if (!empty($lab['schedules'])) {
        foreach ($lab['schedules'] as $sch) {
            $schedule_ids[] = $sch['schedule_id'];
        }
    }
}

$groups = [];
if (count($schedule_ids) > 0) {
    $ids_str = implode(',', $schedule_ids);
    $sql_students = "
        SELECT SE.schedule_id, U.name AS student_name
        FROM STUDENT_ENROLLMENTS SE
        JOIN USERS U ON SE.student_id = U.user_id
        WHERE SE.schedule_id IN ($ids_str) AND SE.is_active = 1
        ORDER BY U.name
    ";
    $res_students = $conn->query($sql_students);
    while ($row = $res_students->fetch_assoc()) {
        $groups[$row['schedule_id']][] = $row['student_name'];
    }
}

// Display results

echo "<table border='1' cellpadding='8' style='border-collapse:collapse; width:100%;'>";
echo "<tr>
    <th>Lab Name</th>
    <th>Location</th>
    <th>Equipment Available</th>
    <th>Schedule Date & Time</th>
    <th>Instructor</th>
    <th>Group (Students)</th>
</tr>";

foreach ($labs as $lab) {
    $rowspan = !empty($lab['schedules']) ? count($lab['schedules']) : 1;
    $first = true;

    if (!empty($lab['schedules'])) {
        foreach ($lab['schedules'] as $schedule) {
            echo "<tr>";
            if ($first) {
                echo "<td rowspan='$rowspan'>{$lab['lab_name']}</td>";
                echo "<td rowspan='$rowspan'>{$lab['location']}</td>";
                echo "<td rowspan='$rowspan'>{$lab['equipment']}</td>";
                $first = false;
            }
            $datetime = $schedule['date'] ? 
                $schedule['date'] . " " . substr($schedule['start_time'],0,5) . "-" . substr($schedule['end_time'],0,5) : 'No schedule';
            $instructor = $schedule['instructor_name'] ?? 'No instructor';

            echo "<td>$datetime</td>";
            echo "<td>$instructor</td>";

            $students_list = isset($groups[$schedule['schedule_id']]) ? implode(', ', $groups[$schedule['schedule_id']]) : 'No students';
            echo "<td>$students_list</td>";
            echo "</tr>";
        }
    } else {
        // No schedules for this lab
        echo "<tr>
            <td>{$lab['lab_name']}</td>
            <td>{$lab['location']}</td>
            <td>{$lab['equipment']}</td>
            <td colspan='3'>No schedules found</td>
        </tr>";
    }
}

echo "</table>";

// Optional: Another list showing schedule + lab name + day/time

echo "<h3>Schedules Summary</h3>";

$sql_schedules = "
SELECT S.schedule_id, L.lab_name, S.scheduled_date, S.start_time, S.end_time, U.name as instructor_name
FROM LAB_SCHEDULE S
JOIN LABS L ON S.lab_id = L.lab_id
LEFT JOIN USERS U ON S.instructor_id = U.user_id
WHERE S.status = 'active'
ORDER BY S.scheduled_date, S.start_time
";

$res_schedules = $conn->query($sql_schedules);

echo "<table border='1' cellpadding='6' style='border-collapse:collapse; width: 60%;'>";
echo "<tr><th>Lab Name</th><th>Date</th><th>Time</th><th>Instructor</th></tr>";
while ($row = $res_schedules->fetch_assoc()) {
    $time = substr($row['start_time'],0,5) . " - " . substr($row['end_time'],0,5);
    echo "<tr>
        <td>{$row['lab_name']}</td>
        <td>{$row['scheduled_date']}</td>
        <td>$time</td>
        <td>" . ($row['instructor_name'] ?? 'No instructor') . "</td>
    </tr>";
}
echo "</table>";
?>

<?php
session_start();
require_once 'functions.php';
check_login();
require_role(['student']);

$pdo = getPDOConnection();
$user_id = $_SESSION['user_id'];

// Get logged-in student name
$stmt = $pdo->prepare("SELECT name FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$student_name = $stmt->fetchColumn();

// Fetch labs
$labs_result = $pdo->query("SELECT lab_id, lab_name FROM LABS")->fetchAll(PDO::FETCH_ASSOC);

// Fetch subjects
$subjects_result = $pdo->query("SELECT subject_id, subject_code, subject_name FROM SUBJECTS ORDER BY semester, subject_code")->fetchAll(PDO::FETCH_ASSOC);

// Fetch coordinators for dropdown
$coordinators_result = $pdo->query("SELECT user_id, name, email FROM users WHERE role = 'coordinator' ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lab_id = $_POST['lab_id'];
    $subject_id = $_POST['subject_id'];
    $schedule_date = $_POST['schedule_date'];
    $additional_reason = trim($_POST['additional_reason']);
    $selected_coordinator_id = $_POST['coordinator_id'];  // new field from form

    if (!isset($_FILES['faculty_letter']) || $_FILES['faculty_letter']['error'] !== UPLOAD_ERR_OK) {
        die("Error uploading faculty letter.");
    }

    $file_tmp = $_FILES['faculty_letter']['tmp_name'];
    $file_type = strtolower(pathinfo($_FILES['faculty_letter']['name'], PATHINFO_EXTENSION));
    if ($file_type !== 'pdf') {
        die("Only PDF files are allowed.");
    }

    $pdf_data = file_get_contents($file_tmp);

    // Insert request with selected coordinator
    $stmt = $pdo->prepare("INSERT INTO lab_schedule_requests
        (lab_id, subject_id, student_name, student_id, schedule_date, faculty_letter_blob, additional_reason, coordinator_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bindParam(1, $lab_id);
    $stmt->bindParam(2, $subject_id);
    $stmt->bindParam(3, $student_name);
    $stmt->bindParam(4, $user_id);
    $stmt->bindParam(5, $schedule_date);
    $stmt->bindParam(6, $pdf_data, PDO::PARAM_LOB);
    $stmt->bindParam(7, $additional_reason);
    $stmt->bindParam(8, $selected_coordinator_id);

    if ($stmt->execute()) {
        $request_id = $pdo->lastInsertId();
        notify_user($selected_coordinator_id, "New lab schedule request #$request_id submitted by student ID $user_id.");
        echo "<p style='color:green;text-align:center;'>Request submitted successfully!</p>";
    } else {
        echo "<p style='color:red;text-align:center;'>Error: " . htmlspecialchars($stmt->errorInfo()[2]) . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Lab Schedule Request Form</title>
<style>
    body { font-family: Arial; background: #f0f8ff; display: flex; justify-content: center; padding: 40px 0; }
    form { background: #fff; padding: 30px 40px; border-radius: 15px; box-shadow: 0 8px 25px rgba(0, 0, 50, 0.1); width: 400px; }
    h2 { text-align: center; color: #1a73e8; margin-bottom: 25px; }
    label { display: block; font-weight: 600; margin-bottom: 6px; color: #333; font-size: 14px; }
    input, select, textarea { width: 100%; padding: 8px 12px; border-radius: 8px; border: 1.8px solid #d1d9e6; font-size: 14px; margin-bottom: 18px; }
    button { width: 100%; background-color: #1a73e8; color: white; font-weight: 700; font-size: 16px; padding: 12px; border: none; border-radius: 12px; cursor: pointer; }
    button:hover { background-color: #155db0; }
</style>
</head>
<body>

<form method="POST" enctype="multipart/form-data">
    <h2>Lab Schedule Request</h2>

    <label for="lab_id">Lab</label>
    <select id="lab_id" name="lab_id" required>
        <option value="">-- Select Lab --</option>
        <?php foreach ($labs_result as $lab): ?>
            <option value="<?= $lab['lab_id'] ?>"><?= htmlspecialchars($lab['lab_name']) ?></option>
        <?php endforeach; ?>
    </select>

    <label for="subject_id">Subject</label>
    <select id="subject_id" name="subject_id" required>
        <option value="">-- Select Subject --</option>
        <?php foreach ($subjects_result as $sub): ?>
            <option value="<?= $sub['subject_id'] ?>"><?= htmlspecialchars($sub['subject_code']) ?> - <?= htmlspecialchars($sub['subject_name']) ?></option>
        <?php endforeach; ?>
    </select>

    <label for="coordinator_id">Coordinator</label>
    <select id="coordinator_id" name="coordinator_id" required>
        <option value="">-- Select Coordinator --</option>
        <?php foreach ($coordinators_result as $coord): ?>
            <option value="<?= $coord['user_id'] ?>"><?= htmlspecialchars($coord['name']) ?> (<?= htmlspecialchars($coord['email']) ?>)</option>
        <?php endforeach; ?>
    </select>

    <label for="schedule_date">Schedule Date</label>
    <input type="date" id="schedule_date" name="schedule_date" required />

    <label for="faculty_letter">Faculty Letter (PDF)</label>
    <input type="file" id="faculty_letter" name="faculty_letter" accept="application/pdf" required />

    <label for="additional_reason">Additional Reason</label>
    <textarea id="additional_reason" name="additional_reason" placeholder="Write your reason here..." required></textarea>

    <button type="submit">Submit Request</button>
</form>

</body>
</html>

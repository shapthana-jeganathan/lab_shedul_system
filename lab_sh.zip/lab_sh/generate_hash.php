<?php
echo "Coordinator hash: " . password_hash("coordinator123", PASSWORD_DEFAULT) . "<br>";
echo "Instructor hash: " . password_hash("instructor123", PASSWORD_DEFAULT) . "<br>";
?>

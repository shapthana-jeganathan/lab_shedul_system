<?php
//session_start();
require_once __DIR__ . '/../functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'coordinator') {
    exit('Access denied');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $coord_id = $_SESSION['user_id'];
    $request_id = $_POST['request_id'];
    $new_status = $_POST['status']; // 'approved' or 'rejected'

    global $pdo;
    $stmt = $pdo->prepare("
        UPDATE RESCHEDULE_REQUESTS
        SET status = ?, reviewed_by = ?
        WHERE request_id = ?
    ");
    $stmt->execute([$new_status, $coord_id, $request_id]);

    log_action($coord_id, "request_{$new_status}", 'reschedule_request', $request_id, null);

    // Notify student
    $s = $pdo->prepare("SELECT student_id FROM RESCHEDULE_REQUESTS WHERE request_id = ?");
    $s->execute([$request_id]);
    $student = $s->fetchColumn();
    if ($student) {
        $msg = "Your reschedule request #{$request_id} has been {$new_status}.";
        notify_user($student, $msg, true);
    }

    header('Location: ../dashboard/coordinator_dashboard.php?msg=Request+{$new_status}');
}
?>

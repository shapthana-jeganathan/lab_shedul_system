<?php
$conn = new mysqli('localhost', 'root', '', 'lab_resheduling_db', 3306);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully!";
?>

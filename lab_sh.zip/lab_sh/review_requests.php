<?php
include 'db_connect.php';
include 'functions.php';
check_login();
require_role(['coordinator']);

// Handle approve/reject actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $request_id = $_POST['request_id'];
    $action = $_POST['action']; // 'approved' or 'rejected'
    $reviewer_id = $_SESSION['user_id'];

    $stmt = $conn->prepare("UPDATE RESCHEDULE_REQUESTS SET status = ?, reviewed_by = ? WHERE request_id = ?");
    $stmt->bind_param("sii", $action, $reviewer_id, $request_id);
    $stmt->execute();

    echo "<div class='alert alert-success'>Request $action.</div>";
}

// Get all pending requests
$sql = "SELECT r.*, u.name FROM RESCHEDULE_REQUESTS r
        JOIN USERS u ON r.student_id = u.user_id
        ORDER BY request_date DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Review Reschedule Requests</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
    <h2>Review Lab Reschedule Requests</h2>

    <?php while ($row = $result->fetch_assoc()) { ?>
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">Student: <?= htmlspecialchars($row['name']) ?></h5>
                <p><strong>Schedule ID:</strong> <?= $row['original_schedule_id'] ?></p>
                <p><strong>Requested Date:</strong> <?= $row['requested_date'] ?></p>
                <p><strong>Reason:</strong> <?= nl2br(htmlspecialchars($row['reason'])) ?></p>
                <p><strong>Status:</strong> <?= ucfirst($row['status']) ?></p>
                <p>
                    <a href="view_letter.php?id=<?= $row['request_id'] ?>" target="_blank" class="btn btn-sm btn-secondary">View Faculty Letter</a>
                </p>
                <?php if ($row['status'] === 'pending') { ?>
                    <form method="POST" class="d-flex gap-2">
                        <input type="hidden" name="request_id" value="<?= $row['request_id'] ?>">
                        <button name="action" value="approved" class="btn btn-success">Approve</button>
                        <button name="action" value="rejected" class="btn btn-danger">Reject</button>
                    </form>
                <?php } else { ?>
                    <p><strong>Reviewed by:</strong> <?= $row['reviewed_by'] ?></p>
                <?php } ?>
            </div>
        </div>
    <?php } ?>
</div>
</body>
</html>

<?php
$conn = new mysqli("localhost", "root", "root123", "lab_resheduling_db");
if ($conn->connect_error) {
    die("DB connection failed: " . $conn->connect_error);
}

// Array of user emails and their unique passwords
$users = [
    '2022e001@eng.jfn.ac.lk' => 'Pass@001',
    '2022e002@eng.jfn.ac.lk' => 'Pass@002',
    '2023e103@eng.jfn.ac.lk' => 'Pass@103',
    '2021e045@eng.jfn.ac.lk' => 'Pass@045',
    '2022e199@eng.jfn.ac.lk' => 'Pass@199',
    'pradeep@jfn.ac.lk' =>'pra@0001',
    'sandya@jfn.ac.lk' =>'san@0001',
    'sutha@jfn.ac.lk'=>'sut@0001',
    // Add more users and passwords here as needed
];

// Prepare the statement once
$stmt = $conn->prepare("UPDATE users SET password_hash = ? WHERE email = ?");
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

// Loop through each user and update their password
foreach ($users as $email => $password_plain) {
    $hash = password_hash($password_plain, PASSWORD_DEFAULT);
    $stmt->bind_param("ss", $hash, $email);
    
    if ($stmt->execute()) {
        echo "Password updated for $email<br>";
    } else {
        echo "Error updating $email: " . $stmt->error . "<br>";
    }
}

$stmt->close();
$conn->close();
?>

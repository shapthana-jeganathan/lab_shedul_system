<?php
include 'db_connect.php';
//session_start();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $name = trim($_POST['name']);
    $password = $_POST['password'];
    $password_confirm = $_POST['password_confirm'];

    // Basic validation
    if (empty($email) || empty($name) || empty($password)) {
        $error = "Please fill in all fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } elseif ($password !== $password_confirm) {
        $error = "Passwords do not match.";
    } else {
        // Check if email already exists
        $stmt = $conn->prepare("SELECT user_id FROM USERS WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error = "Email is already registered.";
        } else {
            $stmt->close();
            // Insert new user
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO USERS (email, name, password_hash, role) VALUES (?, ?, ?, 'student')");
            $stmt->bind_param("sss", $email, $name, $password_hash);
            if ($stmt->execute()) {
                header("Location: login.php?msg=registered");
                exit();
            } else {
                $error = "Registration failed. Please try again.";
            }
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Register - Lab Reschedule System</title>
</head>
<body>
    <h2>Register</h2>
    <?php if (!empty($error)) {
        echo "<p style='color:red;'>$error</p>";
    } ?>
    <form method="POST" action="register.php">
        <label>Name:</label><br />
        <input type="text" name="name" required /><br /><br />

        <label>Email:</label><br />
        <input type="email" name="email" required /><br /><br />

        <label>Password:</label><br />
        <input type="password" name="password" required /><br /><br />

        <label>Confirm Password:</label><br />
        <input type="password" name="password_confirm" required /><br /><br />

        <button type="submit">Register</button>
    </form>

    <p>Already have an account? <a href="login.php">Login here</a>.</p>
</body>
</html>

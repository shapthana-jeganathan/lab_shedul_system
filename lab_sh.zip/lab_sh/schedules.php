<?php
session_start();
require_once 'db_connect.php';
require_once 'functions.php';

check_login();
require_role(['coordinator']);

$coordinator_id = $_SESSION['user_id'];
$success = $error = "";

// Fetch labs and instructors for the dropdown
$lab_result = $conn->query("SELECT lab_id, lab_name FROM labs");
$labs = $lab_result->fetch_all(MYSQLI_ASSOC);

$instructor_result = $conn->query("SELECT instructor_id, instructor_name FROM instructors");
$instructors = $instructor_result->fetch_all(MYSQLI_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lab_id = $_POST['lab_id'];
    $schedule_date = $_POST['schedule_date'];
    $schedule_time = $_POST['schedule_time'];
    $instructor_id = $_POST['instructor_id'];

    $stmt = $conn->prepare("INSERT INTO lab_schedule (lab_id, schedule_date, schedule_time, coordinator_id, instructor_id) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssii", $lab_id, $schedule_date, $schedule_time, $coordinator_id, $instructor_id);

    if ($stmt->execute()) {
        $success = "Schedule created successfully!";
    } else {
        $error = "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Fetch schedules for the logged-in coordinator
$schedule_stmt = $conn->prepare("SELECT s.schedule_id, s.lab_id, l.lab_name, s.schedule_date, s.schedule_time, i.instructor_name
                                 FROM lab_schedule s
                                 JOIN labs l ON s.lab_id = l.lab_id
                                 JOIN instructors i ON s.instructor_id = i.instructor_id
                                 WHERE s.coordinator_id = ?
                                 ORDER BY s.schedule_date DESC, s.schedule_time DESC");
$schedule_stmt->bind_param("i", $coordinator_id);
$schedule_stmt->execute();
$schedule_result = $schedule_stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Create Lab Schedule</title>
    <style>
        body { font-family: Arial; padding: 20px; background-color: #f8f8f8; }
        h2 { color: #1a73e8; }
        label { display: block; margin: 10px 0 5px; }
        input, select { padding: 5px; width: 250px; }
        table { border-collapse: collapse; width: 100%; margin-top: 30px; background: white; }
        th, td { border: 1px solid #ccc; padding: 10px; text-align: center; }
        th { background-color: #1a73e8; color: white; }
        .success { color: green; }
        .error { color: red; }
    </style>
</head>
<body>

<h2>Create New Lab Schedule</h2>

<?php if ($success) echo "<p class='success'>$success</p>"; ?>
<?php if ($error) echo "<p class='error'>$error</p>"; ?>

<form method="post">
    <label>Lab ID:</label>
    <select name="lab_id" required>
        <option value="">-- Select Lab --</option>
        <?php foreach ($labs as $lab): ?>
            <option value="<?= $lab['lab_id'] ?>">
                <?= $lab['lab_id'] . ' - ' . $lab['lab_name'] ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label>Date:</label>
    <input type="date" name="schedule_date" required>

    <label>Time:</label>
    <input type="time" name="schedule_time" required>

    <label>Instructor:</label>
    <select name="instructor_id" required>
        <option value="">-- Select Instructor --</option>
        <?php foreach ($instructors as $inst): ?>
            <option value="<?= $inst['instructor_id'] ?>">
                <?= $inst['instructor_id'] . ' - ' . $inst['instructor_name'] ?>
            </option>
        <?php endforeach; ?>
    </select>

    <br><br>
    <button type="submit">Create Schedule</button>
</form>

<!-- Display schedules created by this coordinator -->
<?php if ($schedule_result->num_rows > 0): ?>
    <h2>Your Schedules</h2>
    <table>
        <thead>
            <tr>
                <th>Schedule ID</th>
                <th>Lab</th>
                <th>Date</th>
                <th>Time</th>
                <th>Instructor</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $schedule_result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['schedule_id']) ?></td>
                    <td><?= htmlspecialchars($row['lab_id'] . ' - ' . $row['lab_name']) ?></td>
                    <td><?= htmlspecialchars($row['schedule_date']) ?></td>
                    <td><?= htmlspecialchars($row['schedule_time']) ?></td>
                    <td><?= htmlspecialchars($row['instructor_name']) ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>No schedules found.</p>
<?php endif; ?>

</body>
</html>

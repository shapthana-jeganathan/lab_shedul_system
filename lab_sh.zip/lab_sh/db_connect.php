<?php
$host = 'localhost';
$user = 'root';
$password = 'root123';
$dbname = 'lab_resheduling_db';

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>

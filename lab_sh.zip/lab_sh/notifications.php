<?php
session_start();
require_once 'functions.php';

check_login();
$pdo = getPDOConnection();

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

// Handle POST actions (approve/reject by coordinator, schedule by instructor)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if ($role === 'coordinator' && isset($_POST['approve_request'])) {
        $request_id = $_POST['request_id'] ?? null;
        $status = $_POST['status'] ?? null;
        if (!$request_id || !in_array($status, ['approved', 'rejected'])) {
            exit("Invalid request or status.");
        }

        $stmt = $pdo->prepare("UPDATE lab_schedule_requests SET status = ?, coordinator_id = ? WHERE request_id = ?");
        $stmt->execute([$status, $user_id, $request_id]);

        $stmt = $pdo->prepare("SELECT student_id, subject_id FROM lab_schedule_requests WHERE request_id = ?");
        $stmt->execute([$request_id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        notify_user($row['student_id'], "Your lab reschedule request #$request_id has been $status by your Coordinator.");

        if ($status === 'approved') {
            // Notify instructors of the subject
            $stmt = $pdo->prepare("SELECT user_id FROM users WHERE role = 'instructor' AND user_id IN (SELECT instructor_id FROM instructors WHERE subject_id = ?)");
            $stmt->execute([$row['subject_id']]);
            $instructors = $stmt->fetchAll(PDO::FETCH_COLUMN);

            foreach ($instructors as $inst_id) {
                notify_user($inst_id, "Request #$request_id approved. Please set a reschedule date.");
            }
        }
    }

    if ($role === 'instructor' && isset($_POST['set_reschedule'])) {
        $request_id = $_POST['request_id'] ?? null;
        $date = $_POST['reschedule_date'] ?? null;
        $time = $_POST['reschedule_time'] ?? null;

        if (!$request_id || !$date || !$time) {
            exit("Missing date/time.");
        }

        $stmt = $pdo->prepare("UPDATE lab_schedule_requests SET reschedule_date = ?, reschedule_time = ?, status = 'scheduled', handled_by_instructor = ? WHERE request_id = ?");
        $stmt->execute([$date, $time, $user_id, $request_id]);

        $stmt = $pdo->prepare("SELECT student_id, coordinator_id FROM lab_schedule_requests WHERE request_id = ?");
        $stmt->execute([$request_id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        notify_user($row['student_id'], "Your request #$request_id has been scheduled on $date at $time.");
        notify_user($row['coordinator_id'], "Request #$request_id scheduled by Instructor for $date at $time.");
    }
}

// Fetch notifications for current user
$stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50");
$stmt->execute([$user_id]);
$notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch requests relevant to user role
if ($role === 'student') {
    $stmt = $pdo->prepare("SELECT r.*, s.subject_name, u.name AS coordinator_name 
        FROM lab_schedule_requests r
        JOIN subjects s ON r.subject_id = s.subject_id
        JOIN users u ON r.coordinator_id = u.user_id
        WHERE r.student_id = ? ORDER BY r.request_date DESC");
    $stmt->execute([$user_id]);
    $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

} elseif ($role === 'coordinator') {
    $stmt = $pdo->prepare("SELECT r.*, s.subject_name, u.name AS student_name
        FROM lab_schedule_requests r
        JOIN subjects s ON r.subject_id = s.subject_id
        JOIN users u ON r.student_id = u.user_id
        WHERE r.status = 'pending' ORDER BY r.request_date DESC");
    $stmt->execute();
    $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

} elseif ($role === 'instructor') {
    $stmt = $pdo->prepare("SELECT r.*, s.subject_name, u.name AS student_name
        FROM lab_schedule_requests r
        JOIN subjects s ON r.subject_id = s.subject_id
        JOIN users u ON r.student_id = u.user_id
        WHERE r.status = 'approved' AND r.reschedule_date IS NULL ORDER BY r.request_date DESC");
    $stmt->execute();
    $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Lab Rescheduling - Notifications</title>
    <style>
        body { font-family: Arial; padding: 20px; max-width: 900px; margin: auto; }
        h2 { color: #2c5282; }
        .notification, .request { padding: 15px; margin: 10px 0; border-radius: 6px; }
        .notification { background: #edf2f7; }
        .request { background: #fff; border: 1px solid #cbd5e0; }
        textarea, input, select { width: 100%; padding: 6px; margin: 8px 0; }
        button { padding: 8px 14px; background: #3182ce; color: white; border: none; border-radius: 4px; cursor: pointer; }
        button:hover { background: #2b6cb0; }
    </style>
</head>
<body>

<h2>Welcome, <?=htmlspecialchars($role)?> (User #<?=htmlspecialchars($user_id)?>)</h2>

<h3>🔔 Notifications</h3>
<?php if (empty($notifications)): ?>
    <p>No notifications yet.</p>
<?php else: ?>
    <?php foreach ($notifications as $n): ?>
        <div class="notification">
            <?=htmlspecialchars($n['message'])?><br>
            <small><i><?=htmlspecialchars($n['created_at'])?></i></small>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<h3>📋 Your Requests</h3>
<?php if (empty($requests)): ?>
    <p>No relevant requests.</p>
<?php else: ?>
    <?php foreach ($requests as $req): ?>
        <div class="request">
            <strong>Request #<?=htmlspecialchars($req['request_id'])?></strong><br>
            Subject: <?=htmlspecialchars($req['subject_name'])?><br>
            <?php if ($role === 'student'): ?>
                Coordinator: <?=htmlspecialchars($req['coordinator_name'])?><br>
            <?php else: ?>
                Student: <?=htmlspecialchars($req['student_name'])?><br>
            <?php endif; ?>
            Reason: <?=nl2br(htmlspecialchars($req['additional_reason']))?><br>
            Status: <?=htmlspecialchars($req['status'])?><br>
            Requested On: <?=htmlspecialchars($req['request_date'])?><br>

            <?php if ($req['status'] === 'scheduled'): ?>
                Scheduled Date: <?=htmlspecialchars($req['reschedule_date'])?><br>
                Scheduled Time: <?=htmlspecialchars($req['reschedule_time'])?><br>
            <?php endif; ?>

            <?php if ($role === 'coordinator' && $req['status'] === 'pending'): ?>
                <form method="post">
                    <input type="hidden" name="request_id" value="<?=$req['request_id']?>">
                    <button type="submit" name="approve_request" value="approved" onclick="this.form.status.value='approved'">Approve</button>
                    <button type="submit" name="approve_request" value="rejected" onclick="this.form.status.value='rejected'">Reject</button>
                    <input type="hidden" name="status" value="">
                </form>
            <?php endif; ?>

            <?php if ($role === 'instructor' && $req['status'] === 'approved' && empty($req['reschedule_date'])): ?>
                <form method="post">
                    <input type="hidden" name="request_id" value="<?=$req['request_id']?>">
                    <label>Date: <input type="date" name="reschedule_date" required></label><br>
                    <label>Time: <input type="time" name="reschedule_time" required></label><br>
                    <button type="submit" name="set_reschedule">Set Schedule</button>
                </form>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

</body>
</html>


<?php
session_start();
require_once 'functions.php';
check_login();

$user_role = $_SESSION['role'];
?>

<!DOCTYPE html>
<html>
<head><title>Dashboard</title></head>
<body>


<h2>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?> (<?php echo ucfirst($user_role); ?>)</h2>

<ul>
    <?php if ($user_role === 'student'): ?>
        <li><a href="reschedule_request.php"> Reschedule Requests</a></li>
        <li><a href="notifications.php">Notifications</a></li>
        <li><a href="logout.php">Logout</a></li>

    <?php elseif ($user_role === 'coordinator' || $user_role === 'instructor'): ?>
        
        <li><a href="attendance.php">Attendance</a></li>
        <li><a href="notifications.php">Notifications</a></li>
        <li><a href="schedules.php">Schedules</a></li>
        <li><a href="logout.php">Logout</a></li>
    <?php else: ?>
        <li><a href="logout.php">Logout</a></li>
    <?php endif; ?>
</ul>

</body>
</html>
